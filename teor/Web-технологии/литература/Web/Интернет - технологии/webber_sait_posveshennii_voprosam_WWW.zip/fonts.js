function testFonts()
{
 msie = navigator.appVersion.indexOf("MSIE");
 if (msie == -1) return;
 vers = parseInt(navigator.appVersion.substr(msie+5));
 if (vers < 6) return;

 document.all("yes6").style.display = "block";
 document.all("font_div").style.display = "block";
 document.all("not6").style.display = "none";

 var temp = "<table width=100% cellpadding=1px cellspacing=1px border=0px bgcolor=#C0C0C0>";
 for (i = 1;i <= dlg.fonts.count;i++)
 {
  font_name = dlg.fonts(i);  
  if (((i-1) % 8) == 0) temp += "<tr class='row-a'>";
  if (((i-1) % 8) == 4) temp += "<tr class='row-b'>";
  temp += "<td class='to-left'>" + font_name +"</td>";
  if (((i-1) % 4) == 3) temp += "</tr>";
 }
 if (dlg.fonts.count % 4 != 0)
  temp += "<td colspan="+ (4 - dlg.fonts.count % 4)+"></tr>";
 document.all("font_div").innerHTML = temp+"</table>";
}
window.onload = testFonts;
