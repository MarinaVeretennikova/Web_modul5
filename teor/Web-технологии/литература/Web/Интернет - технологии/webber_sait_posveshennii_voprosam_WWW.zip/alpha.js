  var dx;
  var dy;
  var minX;
  var maxX;
  var minY;
  var maxY;
  var iTm="";

  function get_position()
  {
   minX = 8;
   minY = 8;
   obj  = img_back;
   while(obj.tagName != "BODY" && obj != null)
   {
    minX += obj.offsetLeft;
    minY += obj.offsetTop;
    obj = obj.offsetParent;
   }
   maxX = minX + img_back.clientWidth-img_flow.clientWidth - 16;
   maxY = minY + img_back.clientHeight-img_flow.clientHeight -14;
  }
  function move_back()
  {
   x = img_flow.offsetLeft;
   y = img_flow.offsetTop;
   if (x<=minX) dx = 1;
   if (y<=minY) dy = 1;    
   if (x>=maxX) dx = -1;
   if (y>=maxY) dy = -1;
   x += dx; y+=dy;
   img_flow.style.left = x+"px";
   img_flow.style.top  = y+"px";

  }
  function place()
  {
   get_position(img_back);
   img_flow.style.left = (minX)+"px";
   img_flow.style.top = (minY)+"px";
   dx = 1;
   dy = 1;
   img_flow.style.visibility = "visible";
  }
  function start_move()
  {
   if (iTm == "")
    iTm = setInterval("move_back();",50);
  }
  function stop_move()
  {
   if (iTm != "")
    clearInterval(iTm);
   iTm = "";
  }
  function reset_move(){stop_move();place();}
  window.onload = place;